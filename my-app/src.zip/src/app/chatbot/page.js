"use client";

import { useState } from "react";

export default function ChatbotPage() {
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content: "Hi! I'm your assistant. How can I help?",
    },
  ]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleSend(e) {
    e.preventDefault();

    const text = input.trim();
    if (!text || busy) return;

    setMessages((cur) => [...cur, { role: "user", content: text }]);
    setInput("");
    setBusy(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text }),
      });

      if (!res.ok) throw new Error("API error");

      const data = await res.json();

      
      setMessages((cur) => [
        ...cur,
        {
          role: "assistant",
          content: data.reply,
          disease: data.disease,
          confidence: data.confidence,
        },
      ]);
    } catch (err) {
      setMessages((cur) => [
        ...cur,
        {
          role: "assistant",
          content: "Something went wrong. Please try again.",
        },
      ]);
    }

    setBusy(false);
  }

  return (
    <section className="min-h-[calc(100dvh-4rem)] bg-[#0f172a]">
      <div className="mx-auto w-full max-w-4xl px-4 md:px-6 lg:px-8 py-6">
        <div className="relative glass rounded-2xl h-[70vh] md:h-[75vh] flex flex-col animate-fade-in">
          <div className="border-b border-white/10 p-3 text-sm font-medium text-zinc-200">
            Medical Chat
          </div>

          <div className="flex-1 space-y-3 overflow-y-auto p-4">
            {messages.map((m, i) => (
              <div
                key={i}
                className={`animate-slide-up max-w-[78%] rounded-2xl px-4 py-2 text-sm leading-relaxed ${
                  m.role === "user"
                    ? "ml-auto bg-emerald-500/15 text-emerald-200 shadow-[0_0_20px_rgba(16,185,129,0.15)]"
                    : "mr-auto bg-[#11151b] text-zinc-200 border border-white/5"
                }`}
              >
                {m.role === "assistant" && m.disease && m.confidence && (
                  <div className="mb-2">
                    <div className="text-emerald-300 font-semibold">Disease: {m.disease}</div>
                    <div className="text-zinc-400 text-xs mt-0.5">Confidence: {m.confidence}%</div>
                  </div>
                )}
                {m.content}
              </div>
            ))}
            {busy && (
              <div className="mr-auto max-w-[78%] rounded-2xl px-4 py-2 bg-[#11151b] border border-white/5 text-zinc-300 inline-flex items-center gap-1">
                <span className="typing-dot">•</span>
                <span className="typing-dot">•</span>
                <span className="typing-dot">•</span>
              </div>
            )}
          </div>

          <form onSubmit={handleSend} className="p-3 flex items-center gap-2 sticky bottom-0">
            <div className="flex w-full rounded-full border border-white/10 bg-black/40 backdrop-blur px-3 py-2">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type your symptoms..."
                className="flex-1 bg-transparent text-sm text-zinc-100 outline-none placeholder:text-zinc-500"
              />
              <button
                type="submit"
                disabled={busy}
                className="btn-press glow rounded-full bg-emerald-400/90 hover:bg-emerald-300 text-black text-sm font-semibold px-4 py-2 disabled:opacity-60"
              >
                {busy ? "Sending..." : "Send"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
}
